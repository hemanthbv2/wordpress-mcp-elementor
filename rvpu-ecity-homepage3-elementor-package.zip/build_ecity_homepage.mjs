process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
import fs from 'node:fs';
import { spawn } from 'node:child_process';

let idCounter = 2000000;
function nextId() {
  idCounter += 1;
  return idCounter.toString(16).slice(-7).padStart(7, '0');
}

// Responsive box helper using 'em' by default for all padding and margin settings
// On desktop (1920px = 120em), 1em = 16px in Figma
function em(top, right, bottom, left, unit = 'em') {
  return {
    unit,
    top: String(top),
    right: String(right),
    bottom: String(bottom),
    left: String(left),
    isLinked: false
  };
}

function withWidgetClasses(extra = {}) {
  if (extra.css_classes && !extra._css_classes) {
    return { ...extra, _css_classes: extra.css_classes };
  }
  return extra;
}

function makeSection(settings = {}, columns = [], isInner = false) {
  return {
    id: nextId(),
    elType: 'section',
    isInner,
    settings: {
      layout: isInner ? 'boxed' : 'full_width',
      gap: 'no',
      ...settings
    },
    elements: columns
  };
}

function makeColumn(size = 100, settings = {}, widgets = [], isInner = false) {
  return {
    id: nextId(),
    elType: 'column',
    isInner,
    settings: {
      _column_size: size,
      _inline_size: size,
      ...(settings.sizeTablet !== undefined ? { _inline_size_tablet: settings.sizeTablet } : {}),
      ...(settings.sizeMobile !== undefined ? { _inline_size_mobile: settings.sizeMobile } : {}),
      ...settings
    },
    elements: widgets
  };
}

// Heading widget using 'em' for desktop, tablet, and mobile font-size, line-height, and margins
// Default scale: Main Heading = 2.5em (Desktop), 2.2em (Tablet), 2.0em (Mobile) in Georgia
function makeHeading(title, settings = {}) {
  const desktopEm = settings.fontSizeEm ?? 2.5;
  const tabletEm = settings.fontSizeTabletEm ?? 2.2;
  const mobileEm = settings.fontSizeMobileEm ?? 2.0;

  return {
    id: nextId(),
    elType: 'widget',
    widgetType: 'heading',
    settings: {
      title,
      header_size: settings.header_size || 'h2',
      align: settings.align || 'left',
      ...(settings.alignTablet ? { align_tablet: settings.alignTablet } : {}),
      ...(settings.alignMobile ? { align_mobile: settings.alignMobile } : {}),
      title_color: settings.color || '#000000',
      typography_typography: 'custom',
      typography_font_family: settings.fontFamily || 'Georgia',
      typography_font_size: { unit: 'em', size: desktopEm, sizes: [] },
      typography_font_size_tablet: { unit: 'em', size: tabletEm, sizes: [] },
      typography_font_size_mobile: { unit: 'em', size: mobileEm, sizes: [] },
      typography_font_weight: String(settings.fontWeight || '700'),
      typography_line_height: { unit: 'em', size: settings.lineHeight || 1.25, sizes: [] },
      ...withWidgetClasses(settings.extra)
    },
    elements: []
  };
}

// Text Editor widget using 'em' for desktop, tablet, and mobile font-size, line-height, and margins
// Default scale: Body = 1.0em (Desktop, Tablet, Mobile) in Inter
function makeText(editorHtml, settings = {}) {
  const desktopEm = settings.fontSizeEm ?? 1.0;
  const tabletEm = settings.fontSizeTabletEm ?? 1.0;
  const mobileEm = settings.fontSizeMobileEm ?? 1.0;

  return {
    id: nextId(),
    elType: 'widget',
    widgetType: 'text-editor',
    settings: {
      editor: editorHtml,
      align: settings.align || 'left',
      ...(settings.alignTablet ? { align_tablet: settings.alignTablet } : {}),
      ...(settings.alignMobile ? { align_mobile: settings.alignMobile } : {}),
      text_color: settings.color || '#000000',
      typography_typography: 'custom',
      typography_font_family: settings.fontFamily || 'Inter',
      typography_font_size: { unit: 'em', size: desktopEm, sizes: [] },
      typography_font_size_tablet: { unit: 'em', size: tabletEm, sizes: [] },
      typography_font_size_mobile: { unit: 'em', size: mobileEm, sizes: [] },
      typography_font_weight: String(settings.fontWeight || '400'),
      typography_line_height: { unit: 'em', size: settings.lineHeight || 1.45, sizes: [] },
      ...withWidgetClasses(settings.extra)
    },
    elements: []
  };
}

// Image widget with responsive % / em sizing + automatic asset class for fallback restoration
function makeImage(media, settings = {}) {
  const rawExtra = settings.extra || {};
  const mergedClasses = [rawExtra.css_classes, media.assetClass].filter(Boolean).join(' ');
  const extraWithAsset = {
    ...rawExtra,
    ...(mergedClasses ? { css_classes: mergedClasses } : {})
  };

  return {
    id: nextId(),
    elType: 'widget',
    widgetType: 'image',
    settings: {
      image: { url: media.url, id: media.id },
      image_size: 'full',
      align: settings.align || 'center',
      ...(settings.alignTablet ? { align_tablet: settings.alignTablet } : {}),
      ...(settings.alignMobile ? { align_mobile: settings.alignMobile } : {}),
      ...(settings.width ? { width: { unit: settings.widthUnit || '%', size: settings.width, sizes: [] } } : {}),
      ...(settings.widthTablet ? { width_tablet: { unit: settings.widthTabletUnit || settings.widthUnit || '%', size: settings.widthTablet, sizes: [] } } : {}),
      ...(settings.widthMobile ? { width_mobile: { unit: settings.widthMobileUnit || settings.widthUnit || '%', size: settings.widthMobile, sizes: [] } } : {}),
      ...(settings.borderRadius ? { image_border_radius: em(settings.borderRadius, settings.borderRadius, settings.borderRadius, settings.borderRadius, 'em') } : {}),
      ...withWidgetClasses(extraWithAsset)
    },
    elements: []
  };
}

// Button widget using 'em' for font-size, border-radius, and text_padding
function makeButton(text, settings = {}) {
  const desktopEm = settings.fontSizeEm ?? 1.0;
  const tabletEm = settings.fontSizeTabletEm ?? 0.95;
  const mobileEm = settings.fontSizeMobileEm ?? 0.9;

  return {
    id: nextId(),
    elType: 'widget',
    widgetType: 'button',
    settings: {
      text,
      link: { url: settings.url || '#', is_external: false, nofollow: false },
      align: settings.align || 'left',
      ...(settings.alignTablet ? { align_tablet: settings.alignTablet } : {}),
      ...(settings.alignMobile ? { align_mobile: settings.alignMobile } : {}),
      size: 'md',
      typography_typography: 'custom',
      typography_font_family: settings.fontFamily || 'Nunito',
      typography_font_size: { unit: 'em', size: desktopEm, sizes: [] },
      typography_font_size_tablet: { unit: 'em', size: tabletEm, sizes: [] },
      typography_font_size_mobile: { unit: 'em', size: mobileEm, sizes: [] },
      typography_font_weight: String(settings.fontWeight || '400'),
      button_text_color: settings.color || '#FFFFFF',
      background_color: settings.bgColor || '#00000000',
      border_border: 'solid',
      border_width: em(0.0625, 0.0625, 0.0625, 0.0625, 'em'),
      border_color: settings.borderColor || '#FFFFFF',
      border_radius: em(2.2, 2.2, 2.2, 2.2, 'em'),
      text_padding: em(0.85, 1.85, 0.85, 1.85, 'em'),
      ...withWidgetClasses(settings.extra)
    },
    elements: []
  };
}

// Native Elementor Image Carousel widget for Results & Events sections
function makeCarousel(mediaList, settings = {}) {
  return {
    id: nextId(),
    elType: 'widget',
    widgetType: 'image-carousel',
    settings: {
      carousel: mediaList.map((m) => ({ id: m.id, url: m.url })),
      thumbnail_size: 'full',
      slides_to_show: String(settings.slidesToShow || 4),
      slides_to_show_tablet: String(settings.slidesToShowTablet || 2),
      slides_to_show_mobile: '1',
      slides_to_scroll: '1',
      image_stretch: 'no',
      navigation: settings.navigation || 'none',
      autoplay: 'yes',
      pause_on_hover: 'yes',
      pause_on_interaction: 'yes',
      autoplay_speed: settings.autoplaySpeed || 2800,
      infinite: 'yes',
      speed: 600,
      image_spacing: 'custom',
      image_spacing_custom: { unit: 'px', size: settings.spacing ?? 30, sizes: [] },
      ...withWidgetClasses(settings.extra)
    },
    elements: []
  };
}

const mediaMap = JSON.parse(
  fs.readFileSync('C:/Users/HP/.gemini/antigravity/brain/c5c230c2-90b4-4fe7-b358-32b81fcbace0/scratch/rvpu_ecity/media_map.json', 'utf8')
);
const GITHUB_ASSET_BASE = 'https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/';
const M = (filename) => {
  const entry = mediaMap[filename] || {};
  const cleanKey = filename.replace(/\.[^.]+$/, '').replace(/[^a-z0-9_-]/gi, '-');
  return {
    id: entry.id || '',
    // Clean .png URL without query string so WordPress wp_check_filetype(basename($url)) succeeds on Elementor JSON import
    url: `${GITHUB_ASSET_BASE}${filename}`,
    filename,
    assetClass: `ecity-asset-${cleanKey}`
  };
};

const MEDIA = {
  logo: M('ecity_logo.png'),
  headerMenu: M('ecity_header_menu.png'),
  heroPlay: M('ecity_hero_play.png'),
  welcomePatternLeft: M('ecity_welcome_pattern_left.png'),
  welcomeCardBgSolid: M('ecity_welcome_card_bg_solid.png'),
  mascotPointing: M('ecity_mascot_pointing.png'),
  campusBuilding: M('ecity_campus_building.png'),
  admissionsBgSolid: M('ecity_admissions_bg_solid.png'),
  iconPhoneTeal: M('ecity_icon_phone_teal.png'),
  iconEmailTeal: M('ecity_icon_email_teal.png'),
  coursesSandGroup: M('ecity_courses_sand_group.png'),
  iconPcmb: M('ecity_icon_pcmb.png'),
  iconPcmc: M('ecity_icon_pcmc.png'),
  iconSabe: M('ecity_icon_sabe.png'),
  iconBams: M('ecity_icon_bams.png'),
  iconBame: M('ecity_icon_bame.png'),
  coursesLabFramed: M('ecity_courses_lab_framed.png'),
  resultsBgSolid: M('ecity_results_bg_solid.png'),
  topperCardFull: M('ecity_topper_card_full.png'),
  arrowLeft: M('ecity_arrow_left.png'),
  arrowRight: M('ecity_arrow_right.png'),
  expandBgSolid: M('ecity_expand_bg_solid.png'),
  expandCircles: M('ecity_expand_circles.png'),
  expandSandBoxSolid: M('ecity_expand_sand_box_solid.png'),
  expandStudents: M('ecity_expand_students.png'),
  mascotLaptop: M('ecity_mascot_laptop.png'),
  eventsBgSolid: M('ecity_events_bg_solid.png'),
  event1: M('ecity_event_1.png'),
  event2: M('ecity_event_2.png'),
  event3: M('ecity_event_3.png'),
  virtualTourBg: M('ecity_virtual_tour_bg.png'),
  footerPhone: M('ecity_footer_phone.png'),
  footerEmail: M('ecity_footer_email.png'),
  footerMap: M('ecity_footer_map.png'),
  footerPrivacy: M('ecity_footer_privacy.png')
};

// Helper for each Course Row (White Circle 133x133px + Terracotta Pill 135px tall)
// Matches exact Figma staircase left offsets: Row 1=170px, Row 2=157px, Row 3=157px, Row 4=145px, Row 5=140px
function makeCourseRow(code, iconMedia, col1Top, col1Bottom, col2Top, col2Bottom, leftOffsetEm = 0, isLast = false) {
  return makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      gap: 'no',
      padding: em(0, 0, 0, leftOffsetEm),
      padding_tablet: em(0, 0, 0, 0),
      padding_mobile: em(0, 0, 0, 0),
      margin: em(0, 0, isLast ? 0 : 1.75, 0),
      margin_mobile: em(0, 0, isLast ? 0 : 1.0, 0),
      css_classes: 'ecity-course-row'
    },
    [
      // Left Column: White Circular Badge (133x133px = 8.3125em x 8.3125em)
      makeColumn(
        24,
        {
          sizeTablet: 25,
          sizeMobile: 28,
          content_position: 'center',
          align: 'center',
          background_background: 'classic',
          background_color: '#FFFFFF',
          border_radius: em(6, 6, 6, 6),
          padding: em(0.95, 0.5, 0.75, 0.5),
          padding_mobile: em(0.65, 0.35, 0.55, 0.35),
          css_classes: 'ecity-course-circle-col'
        },
        [
          makeImage(iconMedia, {
            align: 'center',
            extra: {
              _margin: em(0, 0, 0.35, 0),
              css_classes: 'ecity-course-circle-icon'
            }
          }),
          makeHeading(code, {
            header_size: 'h4',
            align: 'center',
            color: '#000000',
            fontFamily: 'Georgia',
            fontSizeEm: 1.5625, // 25px in Figma
            fontSizeTabletEm: 1.25,
            fontSizeMobileEm: 1.0,
            fontWeight: '400',
            lineHeight: 1.05,
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-course-circle-code'
            }
          })
        ],
        true
      ),
      // Right Column: Terracotta Rounded Pill (#C66E52, 135px tall = 8.4375em, border-radius 15px = 0.9375em)
      makeColumn(
        76,
        {
          sizeTablet: 75,
          sizeMobile: 72,
          content_position: 'center',
          background_background: 'classic',
          background_color: '#C66E52',
          border_radius: em(0.9375, 0.9375, 0.9375, 0.9375),
          padding: em(1.25, 1.35, 1.25, 2.25),
          padding_tablet: em(1.1, 1.1, 1.1, 1.25),
          padding_mobile: em(0.75, 0.75, 0.75, 0.85),
          css_classes: 'ecity-course-pill-col'
        },
        [
          makeText(
            `<div class="ecity-course-pill-grid">
              <div class="ecity-course-pill-half ecity-course-pill-left">
                <div class="ecity-subject-item">${col1Top}</div>
                <div class="ecity-subject-item">${col1Bottom}</div>
              </div>
              <div class="ecity-course-pill-divider"></div>
              <div class="ecity-course-pill-half ecity-course-pill-right">
                <div class="ecity-subject-item">${col2Top}</div>
                <div class="ecity-subject-item">${col2Bottom}</div>
              </div>
            </div>`,
            {
              align: 'left',
              color: '#FFFFFF',
              fontFamily: 'Inter',
              fontSizeEm: 1.0,
              fontSizeTabletEm: 1.0,
              fontSizeMobileEm: 1.0,
              fontWeight: '400',
              lineHeight: 1.28,
              extra: {
                _margin: em(0, 0, 0, 0)
              }
            }
          )
        ],
        true
      )
    ],
    true
  );
}

// Helper for Mobile Course Card (Stacked Terracotta Card with Centered White Circle Badge on Top + 2-Column Subjects Below)
function makeMobileCourseCard(code, iconMedia, col1Top, col1Bottom, col2Top, col2Bottom, isLast = false) {
  return makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      gap: 'no',
      background_background: 'classic',
      background_color: '#C66E52',
      border_radius: em(0.9375, 0.9375, 0.9375, 0.9375),
      padding: em(1.1, 1.35, 1.35, 1.35),
      padding_tablet: em(1.1, 1.35, 1.35, 1.35),
      padding_mobile: em(1.0, 1.15, 1.25, 1.15),
      margin: em(0, 0, isLast ? 1.85 : 1.25, 0),
      margin_mobile: em(0, 0, isLast ? 1.65 : 1.15, 0),
      css_classes: 'ecity-mobile-course-card'
    },
    [
      // Top Centered Column: White Circular Badge (Icon + Course Code in Georgia)
      makeColumn(
        100,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          content_position: 'center',
          align: 'center',
          background_background: 'classic',
          background_color: '#FFFFFF',
          border_radius: em(6, 6, 6, 6),
          padding: em(0.55, 0.35, 0.45, 0.35),
          padding_mobile: em(0.55, 0.35, 0.45, 0.35),
          css_classes: 'ecity-mob-circle-col'
        },
        [
          makeImage(iconMedia, {
            align: 'center',
            extra: {
              _margin: em(0, 0, 0.2, 0),
              css_classes: 'ecity-mob-circle-icon'
            }
          }),
          makeHeading(code, {
            header_size: 'h4',
            align: 'center',
            color: '#000000',
            fontFamily: 'Georgia',
            fontSizeEm: 1.6,
            fontSizeTabletEm: 1.6,
            fontSizeMobileEm: 1.6,
            fontWeight: '400',
            lineHeight: 1.05,
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-mob-circle-code'
            }
          })
        ],
        true
      ),
      // Bottom Full-Width Column: 2-Column Subject Grid with Vertical White Divider
      makeColumn(
        100,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          content_position: 'center',
          padding: em(0.25, 0.25, 0, 0.25),
          padding_mobile: em(0.25, 0.15, 0, 0.15),
          css_classes: 'ecity-mob-subjects-col'
        },
        [
          makeText(
            `<div class="ecity-mob-pill-grid">
              <div class="ecity-mob-pill-half ecity-mob-pill-left">
                <div class="ecity-mob-subject-item">${col1Top}</div>
                <div class="ecity-mob-subject-item">${col1Bottom}</div>
              </div>
              <div class="ecity-mob-pill-divider"></div>
              <div class="ecity-mob-pill-half ecity-mob-pill-right">
                <div class="ecity-mob-subject-item">${col2Top}</div>
                <div class="ecity-mob-subject-item">${col2Bottom}</div>
              </div>
            </div>`,
            {
              align: 'left',
              color: '#FFFFFF',
              fontFamily: 'Inter',
              fontSizeEm: 1.0,
              fontSizeTabletEm: 1.0,
              fontSizeMobileEm: 1.0,
              fontWeight: '400',
              lineHeight: 1.35,
              extra: {
                _margin: em(0, 0, 0, 0)
              }
            }
          )
        ],
        true
      )
    ],
    true
  );
}

const elementorData = [
  // =========================================================================
  // SECTION 1: HEADER BAR (Figma y=1348..1515, h=167px = 10.4375em)
  // Logo at x=69, y=1383, w=256, h=104 (16em x 6.5em)
  // Menu at x=1744, y=1348, w=176, h=167 (11em x 10.4375em, #C66E52)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      background_background: 'classic',
      background_color: '#FFFFFF',
      border_border: 'solid',
      border_width: em(0, 0, 0.125, 0),
      border_color: '#012E59',
      padding: em(0, 0, 0, 4.3125),
      padding_tablet: em(0, 0, 0, 2.0),
      padding_mobile: em(0, 0, 0, 1.0),
      css_classes: 'ecity-header-section'
    },
    [
      makeColumn(
        90.8,
        {
          sizeTablet: 84,
          sizeMobile: 76,
          content_position: 'center',
          padding: em(1.9, 0, 1.9, 0),
          padding_tablet: em(1.1, 0, 1.1, 0),
          padding_mobile: em(0.75, 0, 0.75, 0),
          css_classes: 'ecity-logo-col'
        },
        [
          makeImage(MEDIA.logo, {
            align: 'left',
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-logo-img'
            }
          })
        ]
      ),
      makeColumn(
        9.2,
        {
          sizeTablet: 16,
          sizeMobile: 24,
          background_background: 'classic',
          background_color: '#C66E52',
          content_position: 'center',
          align: 'center',
          padding: em(2.6, 0.5, 2.0, 0.5),
          padding_tablet: em(1.5, 0.5, 1.2, 0.5),
          padding_mobile: em(1.0, 0.4, 0.85, 0.4),
          css_classes: 'ecity-menu-col'
        },
        [
          {
            id: nextId(),
            elType: 'widget',
            widgetType: 'divider',
            settings: {
              style: 'solid',
              weight: { unit: 'px', size: 9, sizes: [] },
              color: '#FAFBFA',
              width: { unit: '%', size: 42, sizes: [] },
              align: 'center',
              gap: { unit: 'px', size: 0, sizes: [] },
              _margin: em(0, 0, 0.65, 0),
              css_classes: 'ecity-menu-bar'
            },
            elements: []
          },
          {
            id: nextId(),
            elType: 'widget',
            widgetType: 'divider',
            settings: {
              style: 'solid',
              weight: { unit: 'px', size: 9, sizes: [] },
              color: '#FAFBFA',
              width: { unit: '%', size: 42, sizes: [] },
              align: 'center',
              gap: { unit: 'px', size: 0, sizes: [] },
              _margin: em(0, 0, 0.65, 0),
              css_classes: 'ecity-menu-bar'
            },
            elements: []
          },
          {
            id: nextId(),
            elType: 'widget',
            widgetType: 'divider',
            settings: {
              style: 'solid',
              weight: { unit: 'px', size: 9, sizes: [] },
              color: '#FAFBFA',
              width: { unit: '%', size: 42, sizes: [] },
              align: 'center',
              gap: { unit: 'px', size: 0, sizes: [] },
              _margin: em(0, 0, 0.55, 0),
              css_classes: 'ecity-menu-bar'
            },
            elements: []
          },
          makeHeading('Menu', {
            header_size: 'span',
            align: 'center',
            color: '#FAFBFA',
            fontFamily: 'Inter',
            fontSizeEm: 1.5625, // 25px in Figma
            fontSizeTabletEm: 1.2,
            fontSizeMobileEm: 1.0,
            fontWeight: '400',
            lineHeight: 1.15
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 2: HERO VIDEO BANNER (Figma y=1515..2372, h=857px = 53.5625em)
  // Play button at x=869, y=1865, w=158, h=158 (9.875em x 9.875em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      background_background: 'classic',
      background_color: '#252525',
      padding: em(21.84, 2, 21.84, 2),
      padding_tablet: em(13, 2, 13, 2),
      padding_mobile: em(8.5, 1.5, 8.5, 1.5),
      css_classes: 'ecity-hero-section'
    },
    [
      makeColumn(
        100,
        {
          content_position: 'center',
          align: 'center'
        },
        [
          makeImage(MEDIA.heroPlay, {
            align: 'center',
            extra: {
              css_classes: 'ecity-play-btn-widget'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 3: WELCOME TO RV PU COLLEGE E-CITY (Figma y=2372..3077, h=705px = 44.0625em)
  // Pattern Left: x=0, y=2372, w=427, h=649 (26.6875em x 40.5625em)
  // Heading: x=294, y=2428, w=565, h=125 (50px = 3.125em Georgia)
  // Terracotta Card: x=277, y=2564, w=679, h=463 (42.4375em x 28.9375em)
  // Sand Bar: x=0, y=3021, w=829, h=56 (51.8125em x 3.5em, #ECD5BC)
  // Mascot Pointing: x=94, y=2529, w=221, h=561 (left: 5.875em, bottom: -0.8125em, w: 13.8125em)
  // Campus Building: x=706, y=2262, w=1222, h=815 (right: -0.5em, bottom: 0, w: 76.375em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      content_position: 'bottom',
      background_background: 'classic',
      background_color: '#FFFFFF',
      background_image: { url: MEDIA.welcomePatternLeft.url, id: MEDIA.welcomePatternLeft.id },
      background_position: 'top left',
      background_repeat: 'no-repeat',
      background_size: 'initial',
      padding: em(0, 0, 0, 0),
      padding_tablet: em(2.2, 1.5, 2.0, 1.5),
      padding_mobile: em(2.0, 1.0, 1.5, 1.0),
      css_classes: 'ecity-welcome-section'
    },
    [
      makeColumn(
        52,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          padding: em(3.5, 0, 3.125, 17.3125),
          padding_tablet: em(1.0, 1.5, 2.0, 1.5),
          padding_mobile: em(0.5, 0, 1.5, 0),
          css_classes: 'ecity-welcome-left-col'
        },
        [
          makeHeading(
            '<span style="font-weight:400;color:#000000;">WELCOME TO</span><br><span style="font-weight:700;color:#000000;">RV PU College</span> <span style="font-weight:700;color:#C66E52;">E-CITY</span>',
            {
              header_size: 'h1',
              align: 'left',
              color: '#000000',
              fontFamily: 'Georgia',
              fontSizeEm: 2.5,
              fontSizeTabletEm: 2.2,
              fontSizeMobileEm: 2.0,
              fontWeight: '700',
              lineHeight: 1.22,
              extra: {
                _margin: em(0, 0, 0.25, 0.34),
                css_classes: 'ecity-welcome-heading'
              }
            }
          ),
          // Terracotta Rounded Card Inner Section (679x463px = 42.4375em x 28.9375em)
          makeSection(
            {
              layout: 'full_width',
              background_background: 'classic',
              background_color: '#C66E52',
              background_image: { url: MEDIA.welcomeCardBgSolid.url, id: MEDIA.welcomeCardBgSolid.id },
              background_position: 'center center',
              background_repeat: 'no-repeat',
              background_size: 'cover',
              border_radius: em(0.9375, 0.9375, 0.9375, 0.9375),
              padding: em(3.25, 3.9375, 3.25, 3.1875),
              padding_tablet: em(2.2, 2.2, 2.0, 2.2),
              padding_mobile: em(1.6, 1.35, 1.6, 1.35),
              css_classes: 'ecity-welcome-card'
            },
            [
              makeColumn(
                100,
                {
                  padding: em(0, 0, 0, 0)
                },
                [
                  makeText(
                    '<p style="margin:0 0 1.25em 0;">Welcome to RV PU College, E-City (RVPU E-City), a vibrant campus at the heart of Bangalore’s leading technology hub. Our mission is to provide a supportive and inspiring learning environment that empowers students to reach their full potential.</p><p style="margin:0;">As a pre-university college, we offer comprehensive education designed to prepare young adults for higher studies and future careers. With experienced faculty, modern classrooms, state-of-the-art facilities and abundant resources, we focus on nurturing both academic excellence and personal growth. At RVPU E-City, we aim to shape well-rounded, confident and successful individuals ready to thrive in an ever-evolving world.</p>',
                    {
                      align: 'left',
                      color: '#FFFFFF',
                      fontFamily: 'Inter',
                      fontSizeEm: 1.0,
                      fontSizeTabletEm: 1.0,
                      fontSizeMobileEm: 1.0,
                      fontWeight: '400',
                      lineHeight: 1.45,
                      extra: {
                        _margin: em(0, 0, 1.5, 0)
                      }
                    }
                  ),
                  makeButton('Know More', {
                    align: 'left',
                    color: '#FFFFFF',
                    borderColor: '#FFFFFF',
                    bgColor: '#00000000',
                    fontSizeEm: 1.0,
                    extra: {
                      css_classes: 'ecity-btn-pill ecity-btn-white'
                    }
                  })
                ],
                true
              )
            ],
            true
          ),
          // Eagle Mascot Pointing Right (221x561px = 13.8125em x 35.0625em at x=94, y=2529)
          makeImage(MEDIA.mascotPointing, {
            align: 'left',
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-welcome-mascot-widget'
            }
          })
        ]
      ),
      makeColumn(
        48,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          content_position: 'bottom',
          padding: em(0, 0, 0, 0),
          css_classes: 'ecity-welcome-right-col'
        },
        [
          makeImage(MEDIA.campusBuilding, {
            align: 'right',
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-campus-building-widget'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 4: ADMISSIONS OPEN 2026 - 2027 (Figma y=3077..3350, h=273px = 17.0625em)
  // Native Section Background Image: MEDIA.admissionsBgSolid (ID 213)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#637982',
      background_image: { url: MEDIA.admissionsBgSolid.url, id: MEDIA.admissionsBgSolid.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(1.75, 2.0, 1.0, 2.0),
      padding_tablet: em(1.75, 1.5, 1.75, 1.5),
      padding_mobile: em(1.6, 1.0, 1.6, 1.0),
      css_classes: 'ecity-admissions-section'
    },
    [
      makeColumn(
        100,
        {
          align: 'center'
        },
        [
          makeHeading(
            '<span class="ecity-adm-white-box">ADMISSIONS OPEN</span><span class="ecity-adm-year-text">2026 -2027</span>',
            {
              header_size: 'h2',
              align: 'center',
              color: '#ECD5BC',
              fontFamily: 'Georgia',
              fontSizeEm: 2.5,
              fontSizeTabletEm: 2.2,
              fontSizeMobileEm: 2.0,
              fontWeight: '700',
              lineHeight: 1.2,
              extra: {
                _margin: em(0, 0, 0.55, 0),
                css_classes: 'ecity-adm-title-widget'
              }
            }
          ),
          makeSection(
            {
              layout: 'full_width',
              content_position: 'middle',
              margin: em(0, 0, 0.9, 0),
              css_classes: 'ecity-adm-enquiries-row'
            },
            [
              makeColumn(
                45,
                {
                  sizeTablet: 100,
                  sizeMobile: 100,
                  content_position: 'center',
                  padding: em(0.35, 0.5, 0.35, 0.5)
                },
                [
                  makeHeading('For Admissions Enquiries:', {
                    header_size: 'h4',
                    align: 'right',
                    alignTablet: 'center',
                    alignMobile: 'center',
                    color: '#FFFFFF',
                    fontFamily: 'Georgia',
                    fontSizeEm: 2.0,
                    fontSizeTabletEm: 1.8,
                    fontSizeMobileEm: 1.6,
                    fontWeight: '400',
                    lineHeight: 1.2
                  })
                ],
                true
              ),
              makeColumn(
                23,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  content_position: 'center',
                  padding: em(0.35, 0.5, 0.35, 0.5),
                  css_classes: 'ecity-adm-contact-col'
                },
                [
                  makeImage(MEDIA.iconPhoneTeal, {
                    align: 'left',
                    extra: {
                      css_classes: 'ecity-adm-circle-icon'
                    }
                  }),
                  makeHeading('<a href="tel:+918317346585" style="color:#FAFBFB;text-decoration:none;">+91 8317346585</a>', {
                    header_size: 'span',
                    align: 'left',
                    color: '#FAFBFB',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.0,
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 1.0,
                    fontWeight: '400',
                    lineHeight: 1.2,
                    extra: {
                      css_classes: 'ecity-adm-contact-text'
                    }
                  })
                ],
                true
              ),
              makeColumn(
                32,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  content_position: 'center',
                  padding: em(0.35, 0.5, 0.35, 0.5),
                  css_classes: 'ecity-adm-contact-col'
                },
                [
                  makeImage(MEDIA.iconEmailTeal, {
                    align: 'left',
                    extra: {
                      css_classes: 'ecity-adm-circle-icon'
                    }
                  }),
                  makeHeading('<a href="mailto:info.rvpus@rvei.edu.in" style="color:#E3E4E3;text-decoration:none;">info.rvpus@rvei.edu.in</a>', {
                    header_size: 'span',
                    align: 'left',
                    color: '#E3E4E3',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.0,
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 1.0,
                    fontWeight: '400',
                    lineHeight: 1.2,
                    extra: {
                      css_classes: 'ecity-adm-contact-text'
                    }
                  })
                ],
                true
              )
            ],
            true
          ),
          makeButton('Know More', {
            align: 'center',
            color: '#FBFBFB',
            borderColor: '#FBFBFB',
            bgColor: '#00000000',
            fontSizeEm: 1.0,
            extra: {
              css_classes: 'ecity-btn-pill ecity-btn-white'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 5: COURSES OFFERED (Figma y=3348..4403, h=1055px = 65.9375em)
  // Native Section Background Image: MEDIA.coursesSandGroup (ID 211)
  // Left 5 rows at x=140..826 (42.875em wide); Right Lab Photo at x=871..1844 (60.8125em x 50.8125em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#ECD5BC',
      background_image: { url: MEDIA.coursesSandGroup.url, id: MEDIA.coursesSandGroup.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(2.6875, 4.75, 2.5, 8.75),
      padding_tablet: em(2.5, 1.5, 2.5, 1.5),
      padding_mobile: em(2.0, 1.0, 2.25, 1.0),
      css_classes: 'ecity-courses-section'
    },
    [
      makeColumn(
        100,
        {},
        [
          makeHeading('COURSES OFFERED', {
            header_size: 'h2',
            align: 'center',
            color: '#252525',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25,
            extra: {
              _margin: em(0, 0, 1.15, 0)
            }
          }),
          makeSection(
            {
              layout: 'full_width',
              content_position: 'middle',
              gap: 'no',
              margin: em(0, 0, 1.85, 0),
              css_classes: 'ecity-courses-main-grid'
            },
            [
              makeColumn(
                42.5,
                {
                  sizeTablet: 100,
                  sizeMobile: 100,
                  padding: em(0, 1.4, 0, 0),
                  padding_tablet: em(0, 0, 1.8, 0),
                  padding_mobile: em(0, 0, 1.5, 0),
                  css_classes: 'ecity-courses-rows-col'
                },
                [
                  // Exact Figma staircase left offsets relative to x=140px:
                  // PCMB: x=170 (+30px = 1.875em)
                  // PCMC: x=157 (+17px = 1.0625em)
                  // SABE: x=157 (+17px = 1.0625em)
                  // BAMS: x=145 (+5px  = 0.3125em)
                  // BAME: x=140 (+0px  = 0em)
                  makeCourseRow('PCMB', MEDIA.iconPcmb, 'Physics', 'Mathematics', 'Chemistry', 'Computer Science', 1.875, false),
                  makeCourseRow('PCMC', MEDIA.iconPcmc, 'Physics', 'Mathematics', 'Chemistry', 'Biology', 1.0625, false),
                  makeCourseRow('SABE', MEDIA.iconSabe, 'Statistics', 'Economics', 'Business Studies', 'Accountancy', 1.0625, false),
                  makeCourseRow('BAMS', MEDIA.iconBams, 'Business Studies', 'Accountancy', 'Basic Mathematics', 'Statistics', 0.3125, false),
                  makeCourseRow('BAME', MEDIA.iconBame, 'Business Studies', 'Accountancy', 'Basic Mathematics', 'Computer Science', 0, true)
                ],
                true
              ),
              makeColumn(
                57.5,
                {
                  sizeTablet: 100,
                  sizeMobile: 100,
                  content_position: 'center',
                  padding: em(0, 0, 0, 1.4),
                  padding_tablet: em(0, 0, 0, 0),
                  padding_mobile: em(0, 0, 0, 0),
                  css_classes: 'ecity-courses-photo-col'
                },
                [
                  makeImage(MEDIA.coursesLabFramed, {
                    align: 'center',
                    width: 100,
                    widthUnit: '%',
                    extra: {
                      css_classes: 'ecity-courses-lab-img'
                    }
                  })
                ],
                true
              )
            ],
            true
          ),
          makeButton('Know More', {
            align: 'center',
            color: '#000000',
            borderColor: '#000000',
            bgColor: '#00000000',
            fontSizeEm: 1.0,
            extra: {
              css_classes: 'ecity-btn-pill ecity-btn-black'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 5B: COURSES OFFERED (MOBILE STACKED CARD VERSION BELOW COURSES)
  // Layout matches mobile reference:
  // 1. "COURSES OFFERED" heading (Georgia 700, 2.5em Desktop / 2.0em Mobile)
  // 2. Framed Lab Photo directly below heading
  // 3. 5 Stacked Terracotta Cards (#C66E52), each with Centered White Circle Badge
  //    (Course Icon + Georgia 1.6em Subheading Code) on top and 2-Column Subject
  //    List (Inter 1.0em Body Font) + Vertical White Divider below
  // 4. Centered "Know More >" Pill Button at bottom
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#ECD5BC',
      background_image: { url: MEDIA.coursesSandGroup.url, id: MEDIA.coursesSandGroup.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(2.5, 2.0, 2.75, 2.0),
      padding_tablet: em(2.25, 1.5, 2.5, 1.5),
      padding_mobile: em(1.85, 0.9, 2.25, 0.9),
      css_classes: 'ecity-courses-mobile-section'
    },
    [
      makeColumn(
        100,
        {
          align: 'center',
          css_classes: 'ecity-courses-mobile-inner-col'
        },
        [
          makeHeading('COURSES OFFERED', {
            header_size: 'h2',
            align: 'center',
            color: '#252525',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25,
            extra: {
              _margin: em(0, 0, 1.0, 0),
              _margin_mobile: em(0, 0, 0.85, 0)
            }
          }),
          makeImage(MEDIA.coursesLabFramed, {
            align: 'center',
            width: 100,
            widthUnit: '%',
            extra: {
              _margin: em(0, 0, 1.5, 0),
              _margin_mobile: em(0, 0, 1.35, 0),
              css_classes: 'ecity-courses-mobile-lab-img'
            }
          }),
          makeMobileCourseCard('PCMB', MEDIA.iconPcmb, 'Physics', 'Mathematics', 'Chemistry', 'Computer Science', false),
          makeMobileCourseCard('PCMC', MEDIA.iconPcmc, 'Physics', 'Mathematics', 'Chemistry', 'Biology', false),
          makeMobileCourseCard('SABE', MEDIA.iconSabe, 'Statistics', 'Economics', 'Chemistry', 'Computer Science', false),
          makeMobileCourseCard('BAMS', MEDIA.iconBams, 'Business Studies', 'Accountancy', 'Basic Mathematics', 'Statistics', false),
          makeMobileCourseCard('BAME', MEDIA.iconBame, 'Business Studies', 'Accountancy', 'Basic Mathematics', 'Computer Science', true),
          makeButton('Know More', {
            align: 'center',
            color: '#000000',
            borderColor: '#000000',
            bgColor: '#00000000',
            fontSizeEm: 1.0,
            extra: {
              css_classes: 'ecity-btn-pill ecity-btn-black'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 6: RESULTS (Figma y=4406..5112, h=706px = 44.125em)
  // Native Section Background Image: MEDIA.resultsBgSolid (ID 214)
  // Left Arrow: x=94, y=4706, 76x73 (4.75em x 4.5625em)
  // 4 Arched Cards: x=231..1684 (340x449px each, 31px gap)
  // Right Arrow: x=1752, y=4704, 76x73 (4.75em x 4.5625em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#FFFFFF',
      background_image: { url: MEDIA.resultsBgSolid.url, id: MEDIA.resultsBgSolid.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(2.8125, 5.5, 2.0, 5.5),
      padding_tablet: em(2.5, 1.25, 2.5, 1.25),
      padding_mobile: em(2.0, 0.75, 2.25, 0.75),
      css_classes: 'ecity-results-section'
    },
    [
      makeColumn(
        100,
        {},
        [
          makeHeading('RESULTS', {
            header_size: 'h2',
            align: 'center',
            color: '#252525',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25,
            extra: {
              _margin: em(0, 0, 1.5, 0)
            }
          }),
          // Native 3-Column Carousel Row: Left Arrow + Native Image Carousel Widget + Right Arrow
          makeSection(
            {
              layout: 'full_width',
              content_position: 'middle',
              gap: 'no',
              margin: em(0, 0, 2.75, 0),
              css_classes: 'ecity-results-slider-row'
            },
            [
              makeColumn(
                6.5,
                {
                  sizeTablet: 10,
                  sizeMobile: 14,
                  content_position: 'center',
                  align: 'left',
                  css_classes: 'ecity-slider-arrow-col'
                },
                [
                  makeImage(MEDIA.arrowLeft, {
                    align: 'left',
                    extra: {
                      css_classes: 'ecity-arrow-btn ecity-results-prev'
                    }
                  })
                ],
                true
              ),
              makeColumn(
                87,
                {
                  sizeTablet: 80,
                  sizeMobile: 72,
                  padding: em(0, 1.5, 0, 1.5),
                  padding_tablet: em(0, 0.5, 0, 0.5),
                  padding_mobile: em(0, 0.25, 0, 0.25),
                  css_classes: 'ecity-results-carousel-col'
                },
                [
                  makeCarousel(
                    [
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull,
                      MEDIA.topperCardFull
                    ],
                    {
                      slidesToShow: 4,
                      slidesToShowTablet: 2,
                      spacing: 30,
                      autoplaySpeed: 2800,
                      extra: {
                        css_classes: 'ecity-results-carousel'
                      }
                    }
                  )
                ],
                true
              ),
              makeColumn(
                6.5,
                {
                  sizeTablet: 10,
                  sizeMobile: 14,
                  content_position: 'center',
                  align: 'right',
                  css_classes: 'ecity-slider-arrow-col'
                },
                [
                  makeImage(MEDIA.arrowRight, {
                    align: 'right',
                    extra: {
                      css_classes: 'ecity-arrow-btn ecity-results-next'
                    }
                  })
                ],
                true
              )
            ],
            true
          ),
          makeButton('Know More', {
            align: 'center',
            color: '#000000',
            borderColor: '#000000',
            bgColor: '#00000000',
            fontSizeEm: 1.0,
            extra: {
              css_classes: 'ecity-btn-pill ecity-btn-black'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 7: EXPAND YOUR POTENTIAL (Figma y=5119..5916, h=797px = 49.8125em)
  // Outer Terracotta Section: MEDIA.expandBgSolid (ID 215, 1920x797)
  // Left Students Photo: x=-2, y=5167, w=749, h=701 (46.8125em x 43.8125em)
  // Heading: x=814, y=5232, "EXPAND YOUR POTENTIAL" (Georgia 700 30px = 1.875em)
  // Warm Sand Band: x=748, y=5285, w=915, h=466 (57.1875em x 29.125em, MEDIA.expandSandBoxSolid ID 216)
  // Right Mascot Laptop: x=1394, y=5215, w=466, h=729 (29.125em x 45.5625em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      background_background: 'classic',
      background_color: '#C66E52',
      background_image: { url: MEDIA.expandBgSolid.url, id: MEDIA.expandBgSolid.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(3.0, 0, 3.0, 0),
      padding_tablet: em(2.5, 1.25, 2.5, 1.25),
      padding_mobile: em(2.0, 1.0, 2.0, 1.0),
      css_classes: 'ecity-expand-section'
    },
    [
      // Left Column (39% = 46.8em = 749px): Students sitting on steps
      makeColumn(
        39,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          content_position: 'center',
          padding: em(0, 0, 0, 0),
          padding_tablet: em(0, 0, 1.5, 0),
          padding_mobile: em(0, 0, 1.25, 0),
          css_classes: 'ecity-expand-left-col'
        },
        [
          makeImage(MEDIA.expandStudents, {
            align: 'left',
            width: 100,
            widthUnit: '%',
            extra: {
              css_classes: 'ecity-expand-students-img'
            }
          })
        ]
      ),
      // Center Column (38%): Heading + Warm Sand Band Inner Section (915x466px = 57.1875em x 29.125em)
      makeColumn(
        38,
        {
          sizeTablet: 65,
          sizeMobile: 100,
          content_position: 'center',
          padding: em(0, 0, 0, 0),
          css_classes: 'ecity-expand-center-col'
        },
        [
          makeHeading('EXPAND YOUR POTENTIAL', {
            header_size: 'h2',
            align: 'left',
            color: '#FFFFFF',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25,
            extra: {
              _margin: em(0, 0, 0.85, 3.3),
              _margin_tablet: em(0, 0, 0.75, 0.5),
              _margin_mobile: em(0, 0, 0.65, 0),
              css_classes: 'ecity-expand-heading'
            }
          }),
          // Warm Sand Band Inner Section (spans 57.1875em = 915px from x=748 to x=1663 behind mascot!)
          makeSection(
            {
              layout: 'full_width',
              background_background: 'classic',
              background_color: '#ECD5BC',
              background_image: { url: MEDIA.expandSandBoxSolid.url, id: MEDIA.expandSandBoxSolid.id },
              background_position: 'center left',
              background_repeat: 'no-repeat',
              background_size: 'cover',
              padding: em(3.125, 20.9375, 2.75, 4.9375),
              padding_tablet: em(2.0, 1.5, 2.0, 1.5),
              padding_mobile: em(1.5, 1.2, 1.5, 1.2),
              css_classes: 'ecity-expand-sand-box'
            },
            [
              makeColumn(
                100,
                {
                  padding: em(0, 0, 0, 0)
                },
                [
                  makeText(
                    '<p style="margin:0 0 1.25em 0;">We have opened doors to learning across Bengaluru, with campuses thoughtfully located to bring quality education closer to you. Each branch carries the same commitment to academic excellence, holistic growth and a student-first environment, yet each has a unique culture shaped by its community and surroundings.</p><p style="margin:0;">Whether you seek an energetic academic hub, a calm learning atmosphere or a space that balances creativity and discipline, you’ll find a campus that feels just right. Explore our centres, learn what makes them special and choose the environment that empowers you to grow, achieve and thrive.</p>',
                    {
                      align: 'left',
                      color: '#000000',
                      fontFamily: 'Inter',
                      fontSizeEm: 1.0,
                      fontSizeTabletEm: 1.0,
                      fontSizeMobileEm: 1.0,
                      fontWeight: '400',
                      lineHeight: 1.45,
                      extra: {
                        _margin: em(0, 0, 1.5, 0),
                        css_classes: 'ecity-expand-body-text'
                      }
                    }
                  ),
                  makeButton('Know More', {
                    align: 'left',
                    color: '#000000',
                    borderColor: '#000000',
                    bgColor: '#00000000',
                    fontSizeEm: 1.0,
                    extra: {
                      css_classes: 'ecity-btn-pill ecity-btn-black'
                    }
                  })
                ],
                true
              )
            ],
            true
          )
        ]
      ),
      // Right Column (23%): Eagle Mascot sitting on stool holding laptop (466x729px = 29.125em x 45.5625em)
      makeColumn(
        23,
        {
          sizeTablet: 35,
          sizeMobile: 100,
          content_position: 'center',
          padding: em(0, 0, 0, 0),
          css_classes: 'ecity-expand-right-col'
        },
        [
          makeImage(MEDIA.mascotLaptop, {
            align: 'center',
            extra: {
              _margin: em(0, 0, 0, 0),
              css_classes: 'ecity-expand-mascot-img'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 8: EVENTS (Figma y=5916..6698, h=782px = 48.875em)
  // Native Section Background Image: MEDIA.eventsBgSolid (ID 217)
  // Left Arrow: x=101, y=6302, 76x73 (4.75em x 4.5625em)
  // 3 Event Cards: x=223..1699 (474x437px each, 27px gap)
  // Right Arrow: x=1746, y=6302, 76x73 (4.75em x 4.5625em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#FFFFFF',
      background_image: { url: MEDIA.eventsBgSolid.url, id: MEDIA.eventsBgSolid.id },
      background_position: 'top center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(3.1875, 5.8, 2.75, 5.8),
      padding_tablet: em(2.5, 1.25, 2.5, 1.25),
      padding_mobile: em(2.0, 0.75, 2.25, 0.75),
      css_classes: 'ecity-events-section'
    },
    [
      makeColumn(
        100,
        {},
        [
          makeHeading('EVENTS', {
            header_size: 'h2',
            align: 'center',
            color: '#000000',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25,
            extra: {
              _margin: em(0, 0, 0.75, 0)
            }
          }),
          makeText(
            '<p style="margin:0;">From academic achievements and cultural celebrations to sports victories, student-led initiatives and inspiring guest sessions, our campus is always alive with energy, creativity and talent. Dive into the experiences that define student life at RVPU E-City.</p>',
            {
              align: 'left',
              color: '#000000',
              fontFamily: 'Inter',
              fontSizeEm: 1.0,
              fontSizeTabletEm: 1.0,
              fontSizeMobileEm: 1.0,
              fontWeight: '400',
              lineHeight: 1.45,
              extra: {
                _margin: em(0, 7.0, 2.1, 7.0),
                _margin_tablet: em(0, 1.5, 1.6, 1.5),
                _margin_mobile: em(0, 0.25, 1.25, 0.25),
                css_classes: 'ecity-events-subtitle'
              }
            }
          ),
          // Native 3-Column Carousel Row: Left Arrow + Native Image Carousel Widget + Right Arrow
          makeSection(
            {
              layout: 'full_width',
              content_position: 'middle',
              gap: 'no',
              margin: em(0, 0, 2.1, 0),
              css_classes: 'ecity-events-slider-row'
            },
            [
              makeColumn(
                6.5,
                {
                  sizeTablet: 10,
                  sizeMobile: 14,
                  content_position: 'center',
                  align: 'left',
                  css_classes: 'ecity-slider-arrow-col'
                },
                [
                  makeImage(MEDIA.arrowLeft, {
                    align: 'left',
                    extra: {
                      css_classes: 'ecity-arrow-btn ecity-events-prev'
                    }
                  })
                ],
                true
              ),
              makeColumn(
                87,
                {
                  sizeTablet: 80,
                  sizeMobile: 72,
                  padding: em(0, 1.25, 0, 1.25),
                  padding_tablet: em(0, 0.5, 0, 0.5),
                  padding_mobile: em(0, 0.25, 0, 0.25),
                  css_classes: 'ecity-events-carousel-col'
                },
                [
                  makeCarousel(
                    [
                      MEDIA.event1,
                      MEDIA.event2,
                      MEDIA.event3,
                      MEDIA.event1,
                      MEDIA.event2,
                      MEDIA.event3
                    ],
                    {
                      slidesToShow: 3,
                      slidesToShowTablet: 2,
                      spacing: 27,
                      autoplaySpeed: 3000,
                      extra: {
                        css_classes: 'ecity-events-carousel'
                      }
                    }
                  )
                ],
                true
              ),
              makeColumn(
                6.5,
                {
                  sizeTablet: 10,
                  sizeMobile: 14,
                  content_position: 'center',
                  align: 'right',
                  css_classes: 'ecity-slider-arrow-col'
                },
                [
                  makeImage(MEDIA.arrowRight, {
                    align: 'right',
                    extra: {
                      css_classes: 'ecity-arrow-btn ecity-events-next'
                    }
                  })
                ],
                true
              )
            ],
            true
          ),
          makeButton('Know More', {
            align: 'center',
            color: '#000000',
            borderColor: '#000000',
            bgColor: '#00000000',
            fontSizeEm: 1.0,
            extra: {
              css_classes: 'ecity-btn-pill ecity-btn-black'
            }
          })
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 9: TAKE A VIRTUAL TOUR OF OUR CAMPUS (Figma y=6698..7205, h=507px = 31.6875em)
  // Native Section Background Image: MEDIA.virtualTourBg (ID 160)
  // Left Text: x=192, y=6851, w=383, h=166 (Georgia 700 40px = 2.5em)
  // Right White Frame: x=762, y=6746, w=1010, h=414 (63.125em x 25.875em)
  // Inner Grey Canvas: x=837, y=6797, w=860, h=313 (53.75em x 19.5625em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      content_position: 'middle',
      background_background: 'classic',
      background_color: '#E8D2B8',
      background_image: { url: MEDIA.virtualTourBg.url, id: MEDIA.virtualTourBg.id },
      background_position: 'center center',
      background_repeat: 'no-repeat',
      background_size: 'cover',
      padding: em(3.0, 9.25, 2.8125, 12.0),
      padding_tablet: em(2.5, 2.0, 2.5, 2.0),
      padding_mobile: em(2.0, 1.0, 2.0, 1.0),
      css_classes: 'ecity-tour-section'
    },
    [
      makeColumn(
        36,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          content_position: 'center',
          padding: em(0, 1.8, 0, 0),
          padding_tablet: em(0, 0, 1.5, 0),
          padding_mobile: em(0, 0, 1.25, 0)
        },
        [
          makeHeading('TAKE A VIRTUAL<br>TOUR OF OUR<br>CAMPUS', {
            header_size: 'h2',
            align: 'left',
            alignTablet: 'center',
            alignMobile: 'center',
            color: '#252525',
            fontFamily: 'Georgia',
            fontSizeEm: 2.5,
            fontSizeTabletEm: 2.2,
            fontSizeMobileEm: 2.0,
            fontWeight: '700',
            lineHeight: 1.25
          })
        ]
      ),
      makeColumn(
        64,
        {
          sizeTablet: 100,
          sizeMobile: 100,
          background_background: 'classic',
          background_color: '#FFFFFF',
          padding: em(3.1875, 4.6875, 3.1875, 4.6875),
          padding_tablet: em(2.0, 2.0, 2.0, 2.0),
          padding_mobile: em(1.25, 1.25, 1.25, 1.25),
          css_classes: 'ecity-tour-white-frame'
        },
        [
          makeSection(
            {
              layout: 'full_width',
              background_background: 'classic',
              background_color: '#EBEBEB',
              padding: em(9.78, 1, 9.78, 1),
              padding_tablet: em(7.0, 1, 7.0, 1),
              padding_mobile: em(5.0, 1, 5.0, 1),
              css_classes: 'ecity-tour-grey-canvas'
            },
            [
              makeColumn(100, {}, [], true)
            ],
            true
          )
        ]
      )
    ]
  ),

  // =========================================================================
  // SECTION 10: FOOTER (Figma y=7204..7958, h=754px = 47.125em)
  // Content container x=285..1636 (1351px = 84.4375em wide; padding left/right = 285px = 17.8125em)
  // =========================================================================
  makeSection(
    {
      layout: 'full_width',
      background_background: 'classic',
      background_color: '#252525',
      padding: em(2.875, 17.8125, 3.5, 17.8125),
      padding_tablet: em(2.5, 2.0, 2.0, 2.0),
      padding_mobile: em(2.0, 1.0, 1.75, 1.0),
      css_classes: 'ecity-footer-section'
    },
    [
      makeColumn(
        100,
        {},
        [
          // Top 4-Icon Contact Bar (x=535..1387, w=852px = 53.25em)
          makeSection(
            {
              layout: 'full_width',
              content_position: 'bottom',
              margin: em(0, 0, 2.5, 0),
              css_classes: 'ecity-footer-top-icons'
            },
            [
              makeColumn(
                25,
                {
                  sizeTablet: 50,
                  sizeMobile: 50,
                  align: 'center',
                  padding: em(0.25, 0.5, 0.25, 0.5)
                },
                [
                  makeImage(MEDIA.footerPhone, {
                    align: 'center',
                    extra: {
                      _margin: em(0, 0, 1.1, 0),
                      css_classes: 'ecity-footer-icon-phone'
                    }
                  }),
                  makeHeading('<a href="tel:+918050454680" style="color:#F7F7F7;text-decoration:none;">+91 80504 54680</a>', {
                    header_size: 'h5',
                    align: 'center',
                    color: '#F7F7F7',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.125, // 18px in Figma
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 0.88,
                    fontWeight: '400',
                    lineHeight: 1.25
                  })
                ],
                true
              ),
              makeColumn(
                25,
                {
                  sizeTablet: 50,
                  sizeMobile: 50,
                  align: 'center',
                  padding: em(0.25, 0.5, 0.25, 0.5)
                },
                [
                  makeImage(MEDIA.footerEmail, {
                    align: 'center',
                    extra: {
                      _margin: em(0, 0, 1.35, 0),
                      css_classes: 'ecity-footer-icon-std'
                    }
                  }),
                  makeHeading('<a href="mailto:info.rvpun@rvei.edu.in" style="color:#F7F7F7;text-decoration:none;">info.rvpun@rvei.edu.in</a>', {
                    header_size: 'h5',
                    align: 'center',
                    color: '#F7F7F7',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.125,
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 0.88,
                    fontWeight: '400',
                    lineHeight: 1.25
                  })
                ],
                true
              ),
              makeColumn(
                25,
                {
                  sizeTablet: 50,
                  sizeMobile: 50,
                  align: 'center',
                  padding: em(0.25, 0.5, 0.25, 0.5)
                },
                [
                  makeImage(MEDIA.footerMap, {
                    align: 'center',
                    extra: {
                      _margin: em(0, 0, 1.35, 0),
                      css_classes: 'ecity-footer-icon-std'
                    }
                  }),
                  makeHeading('<a href="#map" style="color:#F7F7F7;text-decoration:none;">MAP</a>', {
                    header_size: 'h5',
                    align: 'center',
                    color: '#F7F7F7',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.125,
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 0.88,
                    fontWeight: '400',
                    lineHeight: 1.25
                  })
                ],
                true
              ),
              makeColumn(
                25,
                {
                  sizeTablet: 50,
                  sizeMobile: 50,
                  align: 'center',
                  padding: em(0.25, 0.5, 0.25, 0.5)
                },
                [
                  makeImage(MEDIA.footerPrivacy, {
                    align: 'center',
                    extra: {
                      _margin: em(0, 0, 1.35, 0),
                      css_classes: 'ecity-footer-icon-std'
                    }
                  }),
                  makeHeading('<a href="#privacy" style="color:#F7F7F7;text-decoration:none;">PRIVACY POLICY</a>', {
                    header_size: 'h5',
                    align: 'center',
                    color: '#F7F7F7',
                    fontFamily: 'Inter',
                    fontSizeEm: 1.125,
                    fontSizeTabletEm: 1.0,
                    fontSizeMobileEm: 0.88,
                    fontWeight: '400',
                    lineHeight: 1.25
                  })
                ],
                true
              )
            ],
            true
          ),

          // Divider 1
          {
            id: nextId(),
            elType: 'widget',
            widgetType: 'divider',
            settings: {
              style: 'solid',
              weight: { unit: 'px', size: 1, sizes: [] },
              color: '#FAFBFA80',
              width: { unit: '%', size: 100, sizes: [] },
              align: 'center',
              gap: { unit: 'px', size: 0, sizes: [] },
              _margin: em(0, 0, 2.75, 0)
            },
            elements: []
          },

          // Middle 4-Column Row: Know Us | Address | Subscribe with us | Follow Us
          makeSection(
            {
              layout: 'full_width',
              content_position: 'top',
              margin: em(0, 0, 3.25, 0),
              css_classes: 'ecity-footer-mid-row'
            },
            [
              makeColumn(
                20,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  padding: em(0, 1.0, 0, 0),
                  padding_mobile: em(0, 0, 1.5, 0)
                },
                [
                  makeHeading('Know Us', {
                    header_size: 'h4',
                    align: 'left',
                    color: '#F5F5F5',
                    fontFamily: 'Georgia',
                    fontSizeEm: 2.0,
                    fontSizeTabletEm: 1.8,
                    fontSizeMobileEm: 1.6,
                    fontWeight: '400',
                    lineHeight: 1.25,
                    extra: {
                      _margin: em(0, 0, 0.85, 0)
                    }
                  }),
                  makeText(
                    '<div class="ecity-footer-links"><a href="#">About RV PU North</a><br><a href="#">Course</a><br><a href="#">Terms &amp; Conditions</a></div>',
                    {
                      align: 'left',
                      color: '#FAFBFB',
                      fontFamily: 'Inter',
                      fontSizeEm: 1.0,
                      fontSizeTabletEm: 1.0,
                      fontSizeMobileEm: 1.0,
                      fontWeight: '400',
                      lineHeight: 2.25
                    }
                  )
                ],
                true
              ),
              makeColumn(
                22.5,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  padding: em(0, 1.5, 0, 0),
                  padding_mobile: em(0, 0, 1.5, 0)
                },
                [
                  makeHeading('Address', {
                    header_size: 'h4',
                    align: 'left',
                    color: '#F5F5F5',
                    fontFamily: 'Georgia',
                    fontSizeEm: 2.0,
                    fontSizeTabletEm: 1.8,
                    fontSizeMobileEm: 1.6,
                    fontWeight: '400',
                    lineHeight: 1.25,
                    extra: {
                      _margin: em(0, 0, 0.85, 0)
                    }
                  }),
                  makeText(
                    '<p style="margin:0;">DPS Bengaluru North Campus, Survey No. 35/1A, Sathnur Village, Bagalur Post, Off Bellary Road, Jalla Hobli, Bengaluru - 562149, Karnataka, India</p>',
                    {
                      align: 'left',
                      color: '#FAFBFB',
                      fontFamily: 'Inter',
                      fontSizeEm: 1.0,
                      fontSizeTabletEm: 1.0,
                      fontSizeMobileEm: 1.0,
                      fontWeight: '400',
                      lineHeight: 1.55
                    }
                  )
                ],
                true
              ),
              makeColumn(
                32.5,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  padding: em(0, 1.25, 0, 0.25),
                  padding_tablet: em(1.25, 1.0, 0, 0),
                  padding_mobile: em(0, 0, 1.5, 0)
                },
                [
                  makeHeading('Subscribe with us', {
                    header_size: 'h4',
                    align: 'left',
                    color: '#FFFFFF',
                    fontFamily: 'Georgia',
                    fontSizeEm: 2.0,
                    fontSizeTabletEm: 1.8,
                    fontSizeMobileEm: 1.6,
                    fontWeight: '400',
                    lineHeight: 1.25,
                    extra: {
                      _margin: em(0, 0, 1.1, 0)
                    }
                  }),
                  makeText(
                    `<form class="ecity-subscribe-form" onsubmit="event.preventDefault();">
                      <input type="email" placeholder="Enter Email Address" class="ecity-subscribe-input" />
                      <button type="submit" class="ecity-subscribe-submit" aria-label="Subscribe">&#10095;</button>
                    </form>`,
                    {
                      align: 'left',
                      color: '#FFFFFF',
                      fontFamily: 'Inter',
                      fontSizeEm: 1.0,
                      fontWeight: '400'
                    }
                  )
                ],
                true
              ),
              makeColumn(
                25,
                {
                  sizeTablet: 50,
                  sizeMobile: 100,
                  padding: em(0, 0, 0, 0),
                  padding_tablet: em(1.25, 0, 0, 0),
                  padding_mobile: em(0, 0, 0.75, 0)
                },
                [
                  makeHeading('Follow Us', {
                    header_size: 'h4',
                    align: 'left',
                    color: '#FFFFFF',
                    fontFamily: 'Georgia',
                    fontSizeEm: 2.0,
                    fontSizeTabletEm: 1.8,
                    fontSizeMobileEm: 1.6,
                    fontWeight: '400',
                    lineHeight: 1.25,
                    extra: {
                      _margin: em(0, 0, 1.1, 0)
                    }
                  }),
                  makeText(
                    `<div class="ecity-social-dots">
                      <a href="#" class="ecity-social-circle" aria-label="Social 1"></a>
                      <a href="#" class="ecity-social-circle" aria-label="Social 2"></a>
                      <a href="#" class="ecity-social-circle" aria-label="Social 3"></a>
                      <a href="#" class="ecity-social-circle" aria-label="Social 4"></a>
                      <a href="#" class="ecity-social-circle" aria-label="Social 5"></a>
                      <a href="#" class="ecity-social-circle" aria-label="Social 6"></a>
                    </div>`,
                    {
                      align: 'left',
                      color: '#FFFFFF',
                      fontSizeEm: 1.0
                    }
                  )
                ],
                true
              )
            ],
            true
          ),

          // Divider 2
          {
            id: nextId(),
            elType: 'widget',
            widgetType: 'divider',
            settings: {
              style: 'solid',
              weight: { unit: 'px', size: 1, sizes: [] },
              color: '#FAFBFA80',
              width: { unit: '%', size: 100, sizes: [] },
              align: 'center',
              gap: { unit: 'px', size: 0, sizes: [] },
              _margin: em(0, 0, 1.35, 0)
            },
            elements: []
          },

          // Bottom Copyright Bar
          makeSection(
            {
              layout: 'full_width',
              content_position: 'middle',
              css_classes: 'ecity-footer-bottom-row'
            },
            [
              makeColumn(
                35,
                {
                  sizeTablet: 40,
                  sizeMobile: 100
                },
                [
                  makeText('Copyright 2025 RVPU', {
                    align: 'left',
                    alignMobile: 'center',
                    color: '#FAFBFB',
                    fontFamily: 'Inter',
                    fontSizeEm: 0.9375, // 15px in Figma
                    fontSizeTabletEm: 0.875,
                    fontSizeMobileEm: 0.825,
                    fontWeight: '400',
                    lineHeight: 1.35
                  })
                ],
                true
              ),
              makeColumn(
                65,
                {
                  sizeTablet: 60,
                  sizeMobile: 100
                },
                [
                  makeText(
                    'All Rights Reserved Website Design and Development By Department of Alumni Affairs',
                    {
                      align: 'right',
                      alignMobile: 'center',
                      color: '#FAFBFB',
                      fontFamily: 'Inter',
                      fontSizeEm: 0.9375, // 15px in Figma
                      fontSizeTabletEm: 0.875,
                      fontSizeMobileEm: 0.825,
                      fontWeight: '400',
                      lineHeight: 1.35
                    }
                  ),
                  // Scoped Responsive CSS (using em units scaled 1:1 to the 1920px / 120em Figma frame) + Infinite Carousel Controller
                  {
                    id: nextId(),
                    elType: 'widget',
                    widgetType: 'html',
                    settings: {
                      html: `<style>
/* === RVPU E-CITY HOMEPAGE-3 PIXEL-ACCURATE FIGMA STYLING (EM UNITS) === */
html, body {
  overflow-x: hidden !important;
  margin: 0;
  padding: 0;
}

/* On desktop (>1024px), 120em = 100vw (so at 1920px, 1em = 16px, and on 1366px/1440px/1536px laptops every section preserves exact 1920px Figma proportions!) */
@media (min-width: 1025px) {
  .elementor {
    font-size: calc(100vw / 120) !important;
    overflow-x: hidden !important;
  }
}
@media (max-width: 1024px) {
  .elementor {
    font-size: 16px !important;
    overflow-x: hidden !important;
  }
}

/* Pill Buttons with Right Chevron Arrow (183x60px = 11.4375em x 3.75em in Figma) */
.ecity-btn-pill .elementor-button {
  min-width: 11.4375em !important;
  min-height: 3.75em !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  border-radius: 2.2em !important;
  padding: 0.75em 1.75em !important;
  font-family: 'Nunito', 'Inter', sans-serif !important;
  font-size: 1em !important;
  font-weight: 400 !important;
  transition: all 0.25s ease !important;
}
.ecity-btn-pill .elementor-button-text::after {
  content: '\\276F';
  display: inline-block;
  margin-left: 1.1em;
  font-size: 1.05em;
  font-weight: 700;
  line-height: 1;
  transform: translateY(0.05em);
}
.ecity-btn-white .elementor-button {
  border: 0.0625em solid #FFFFFF !important;
  color: #FFFFFF !important;
}
.ecity-btn-white .elementor-button:hover {
  background-color: #FFFFFF !important;
  color: #C66E52 !important;
}
.ecity-btn-black .elementor-button {
  border: 0.0625em solid #000000 !important;
  color: #000000 !important;
}
.ecity-btn-black .elementor-button:hover {
  background-color: #C66E52 !important;
  border-color: #C66E52 !important;
  color: #FFFFFF !important;
}

/* === SECTION 1: HEADER (1920x167px = 120em x 10.4375em) === */
.ecity-header-section {
  min-height: 10.4375em;
}
.ecity-logo-img img {
  width: 16em !important;
  max-width: 100% !important;
  height: auto !important;
  display: block;
}
.ecity-menu-col {
  cursor: pointer;
  min-height: 10.4375em;
}
.ecity-menu-bar .elementor-divider-separator {
  width: 4.375em !important;
  border-top-width: 0.5625em !important;
  border-radius: 0.28em !important;
}

/* === SECTION 2: HERO VIDEO BANNER (1920x857px = 120em x 53.5625em) === */
.ecity-play-btn-widget img {
  width: 9.875em !important;
  height: 9.875em !important;
  cursor: pointer;
  transition: transform 0.25s ease;
}
.ecity-play-btn-widget img:hover {
  transform: scale(1.06);
}

/* === SECTION 3: WELCOME TO RV PU COLLEGE E-CITY (1920x705px = 120em x 44.0625em) === */
.ecity-welcome-section {
  position: relative;
  min-height: 44.0625em;
  overflow: visible !important;
  /* Scale 2x retina pattern (854x1298) to exact 1x Figma size (427x649px = 26.6875em x 40.5625em) */
  background-size: 26.6875em 40.5625em !important;
}
/* Warm Sand Bar at bottom-left: x=0, y=3021, w=829, h=56 (51.8125em x 3.5em) */
.ecity-welcome-section::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 51.8125em;
  height: 3.5em;
  background-color: #ECD5BC;
  z-index: 1;
  pointer-events: none;
}
.ecity-welcome-left-col {
  position: relative;
  z-index: 2;
}
/* Terracotta Card: x=277, y=2564, w=679, h=463 (42.4375em x 28.9375em) */
.ecity-welcome-card {
  position: relative;
  z-index: 2;
  width: 42.4375em !important;
  max-width: 42.4375em !important;
  min-height: 28.9375em;
  margin-bottom: 0 !important;
}
/* Pointing Eagle Mascot: x=94, y=2529, w=221, h=561 (left: 5.875em, bottom: -0.8125em, w: 13.8125em) */
.ecity-welcome-mascot-widget {
  position: absolute !important;
  left: 5.875em !important;
  bottom: -0.8125em !important;
  width: 13.8125em !important;
  max-width: 13.8125em !important;
  z-index: 6 !important;
  pointer-events: none;
  margin: 0 !important;
}
.ecity-welcome-mascot-widget .elementor-widget-container,
.ecity-welcome-mascot-widget .elementor-image {
  width: 100% !important;
}
.ecity-welcome-mascot-widget img {
  width: 13.8125em !important;
  max-width: none !important;
  height: auto !important;
  display: block !important;
}
/* Campus Building Cutout: x=706, y=2262, w=1222, h=815 (right: -0.5em, bottom: 0, w: 76.375em) */
.ecity-welcome-right-col {
  position: static !important;
  pointer-events: none;
}
.ecity-welcome-right-col > .elementor-widget-wrap,
.ecity-welcome-right-col > .elementor-column-wrap,
.ecity-welcome-right-col > .elementor-column-wrap > .elementor-widget-wrap {
  position: static !important;
}
.ecity-campus-building-widget {
  position: absolute !important;
  right: -0.5em !important;
  bottom: 0 !important;
  width: 76.375em !important;
  max-width: none !important;
  z-index: 3 !important;
  pointer-events: none;
  margin: 0 !important;
}
.ecity-campus-building-widget img {
  width: 76.375em !important;
  max-width: none !important;
  height: auto !important;
  display: block !important;
}

/* === SECTION 4: ADMISSIONS OPEN 2026 - 2027 (1920x273px = 120em x 17.0625em) === */
.ecity-admissions-section {
  position: relative;
  z-index: 4;
  min-height: 17.0625em;
}
/* White box (439x56px) with #758A93 Georgia 700 40px text */
.ecity-adm-white-box {
  background: #FFFFFF;
  color: #758A93;
  font-family: Georgia, serif;
  font-weight: 700;
  padding: 0.08em 0.32em;
  display: inline-block;
  margin-right: 0.22em;
  line-height: 1.15;
}
.ecity-adm-year-text {
  color: #ECD5BC;
  font-family: 'Inter', sans-serif;
  font-weight: 700;
}
.ecity-adm-enquiries-row {
  max-width: 68em !important;
  margin-left: auto !important;
  margin-right: auto !important;
}
.ecity-adm-contact-col > .elementor-widget-wrap,
.ecity-adm-contact-col > .elementor-column-wrap > .elementor-widget-wrap {
  display: flex !important;
  flex-direction: row !important;
  align-items: center !important;
  justify-content: center !important;
  flex-wrap: nowrap !important;
  gap: 0.95em;
}
.ecity-adm-circle-icon {
  width: auto !important;
  margin-bottom: 0 !important;
}
/* Double-ring circle: 40x40px (2.5em) solid #FDFDFD inside 54x54px (3.375em) thin white ring */
.ecity-adm-circle-icon .elementor-widget-container {
  width: 2.5em;
  height: 2.5em;
  border-radius: 50%;
  background: #FDFDFD;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0.4375em;
}
.ecity-adm-circle-icon .elementor-widget-container::after {
  content: '';
  position: absolute;
  inset: -0.4375em;
  border-radius: 50%;
  border: 0.0625em solid rgba(255, 255, 255, 0.88);
  pointer-events: none;
}
.ecity-adm-circle-icon img {
  width: 1.375em !important;
  height: auto !important;
  display: block !important;
}
.ecity-adm-contact-text {
  width: auto !important;
  margin-bottom: 0 !important;
}

/* === SECTION 5: COURSES OFFERED (1920x1055px = 120em x 65.9375em) === */
.ecity-course-row > .elementor-container {
  display: flex !important;
  align-items: center !important;
}
/* White Circle Badge: 133x133px = 8.3125em x 8.3125em, gap to pill = 38px = 2.375em */
.ecity-course-circle-col {
  width: 8.3125em !important;
  max-width: 8.3125em !important;
  min-width: 8.3125em !important;
  height: 8.3125em !important;
  border-radius: 50% !important;
  background: #FFFFFF !important;
  box-shadow: 0 0.25em 0.65em rgba(0, 0, 0, 0.2) !important;
  margin-right: 2.375em !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex-shrink: 0 !important;
}
.ecity-course-circle-icon img {
  width: 3.0em !important;
  height: 3.1em !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
/* Terracotta Pill: height 135px = 8.4375em, border-radius 15px = 0.9375em */
.ecity-course-pill-col {
  flex: 1 1 auto !important;
  min-height: 8.4375em !important;
  border-radius: 0.9375em !important;
  box-shadow: 0 0.25em 0.65em rgba(0, 0, 0, 0.2) !important;
  display: flex !important;
  align-items: center !important;
}
.ecity-course-pill-grid {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  gap: 1.1em;
}
.ecity-course-pill-left {
  flex: 0 0 43%;
  display: flex;
  flex-direction: column;
  gap: 0.45em;
}
.ecity-course-pill-right {
  flex: 0 0 52%;
  display: flex;
  flex-direction: column;
  gap: 0.45em;
}
/* Vertical white line inside pill: 1x93px = 0.0625em x 5.8125em */
.ecity-course-pill-divider {
  width: 0.0625em;
  height: 5.8125em;
  background: #FFFFFF;
  flex-shrink: 0;
}
/* Subject text: Inter 400 25px = 1.5625em in Figma */
.ecity-subject-item {
  color: #FFFFFF;
  font-family: 'Inter', sans-serif;
  font-size: 1.5625em;
  font-weight: 400;
  line-height: 1.25;
  white-space: nowrap;
}
.ecity-courses-lab-img img {
  width: 100% !important;
  height: auto !important;
  display: block !important;
}

/* === SECTION 5B: MOBILE COURSES OFFERED SECTION (STACKED CARDS BELOW COURSES) === */
.ecity-courses-mobile-section,
.ecity-courses-section {
  box-sizing: border-box !important;
  max-width: 100vw !important;
  overflow-x: hidden !important;
}
.ecity-courses-mobile-inner-col {
  width: 100% !important;
  max-width: 30em !important;
  margin-left: auto !important;
  margin-right: auto !important;
  box-sizing: border-box !important;
}
.ecity-courses-mobile-lab-img {
  width: 95% !important;
  max-width: 24.5em !important;
  margin-left: auto !important;
  margin-right: auto !important;
}
.ecity-courses-mobile-lab-img img {
  width: 100% !important;
  height: auto !important;
  display: block !important;
  margin: 0 auto !important;
}
.ecity-mobile-course-card {
  width: 92% !important;
  max-width: 23.5em !important;
  margin-left: auto !important;
  margin-right: auto !important;
  border-radius: 0.9375em !important;
  background: #C66E52 !important;
  box-shadow: 0 0.25em 0.65em rgba(0, 0, 0, 0.22) !important;
  box-sizing: border-box !important;
}
.ecity-mobile-course-card > .elementor-container {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: center !important;
  width: 100% !important;
}
.ecity-mob-circle-col {
  width: 6.8em !important;
  min-width: 6.8em !important;
  max-width: 6.8em !important;
  height: 6.8em !important;
  border-radius: 50% !important;
  background: #FFFFFF !important;
  box-shadow: 0 0.2em 0.5em rgba(0, 0, 0, 0.25) !important;
  margin: 0 auto 0.95em auto !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex-shrink: 0 !important;
}
.ecity-mob-circle-col > .elementor-widget-wrap,
.ecity-mob-circle-col > .elementor-column-wrap,
.ecity-mob-circle-col > .elementor-column-wrap > .elementor-widget-wrap {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: center !important;
  width: 100% !important;
  height: 100% !important;
  padding: 0.35em !important;
}
.ecity-mob-circle-icon {
  margin-bottom: 0.2em !important;
}
.ecity-mob-circle-icon img {
  width: 2.35em !important;
  height: 2.35em !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.ecity-mob-circle-code .elementor-heading-title {
  line-height: 1.05 !important;
  margin: 0 !important;
}
.ecity-mob-subjects-col {
  width: 100% !important;
}
.ecity-mob-pill-grid {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  gap: 0.75em;
}
.ecity-mob-pill-left {
  flex: 1 1 46%;
  display: flex;
  flex-direction: column;
  gap: 0.45em;
  text-align: left;
  padding-left: 0.25em;
}
.ecity-mob-pill-right {
  flex: 1 1 48%;
  display: flex;
  flex-direction: column;
  gap: 0.45em;
  text-align: left;
  padding-left: 0.2em;
}
.ecity-mob-pill-divider {
  width: 0.0625em;
  height: 3.35em;
  background: rgba(255, 255, 255, 0.85);
  flex-shrink: 0;
}
.ecity-mob-subject-item {
  color: #FFFFFF;
  font-family: 'Inter', sans-serif;
  font-size: 1.0em;
  font-weight: 400;
  line-height: 1.3;
}

/* === SECTION 6 & 8: RESULTS & EVENTS NATIVE CAROUSELS === */
.ecity-results-slider-row > .elementor-container,
.ecity-events-slider-row > .elementor-container,
.ecity-tour-section > .elementor-container {
  display: flex !important;
  align-items: center !important;
}
.ecity-results-carousel-col,
.ecity-events-carousel-col,
.ecity-course-pill-col {
  min-width: 0 !important;
}
.ecity-slider-arrow-col,
.ecity-slider-arrow-col > .elementor-widget-wrap,
.ecity-slider-arrow-col > .elementor-column-wrap,
.ecity-slider-arrow-col > .elementor-column-wrap > .elementor-widget-wrap {
  display: flex !important;
  align-items: center !important;
}
/* Prev/Next Arrow Buttons: 76x73px = 4.75em x 4.5625em in Figma */
.ecity-arrow-btn img {
  width: 4.75em !important;
  height: 4.5625em !important;
  max-width: none !important;
  cursor: pointer;
  transition: transform 0.2s ease;
  display: block !important;
}
.ecity-arrow-btn img:hover {
  transform: scale(1.06);
}
.ecity-results-carousel,
.ecity-events-carousel,
.ecity-results-carousel > .elementor-widget-container,
.ecity-events-carousel > .elementor-widget-container {
  width: 100% !important;
}
.ecity-results-carousel .swiper-slide img {
  width: 100% !important;
  max-width: 21.25em !important;
  height: auto !important;
  margin: 0 auto !important;
  display: block !important;
}
.ecity-events-carousel .swiper-slide img {
  width: 100% !important;
  height: 27.3125em !important;
  object-fit: cover !important;
  border-radius: 0.9375em !important;
  display: block !important;
}

/* === SECTION 7: EXPAND YOUR POTENTIAL (1920x797px = 120em x 49.8125em) === */
.ecity-expand-section {
  position: relative;
  min-height: 49.8125em;
  overflow: visible !important;
  z-index: 5;
}
.ecity-expand-left-col {
  position: relative;
  z-index: 3;
}
.ecity-expand-center-col {
  position: relative;
  z-index: 2;
  overflow: visible !important;
}
.ecity-expand-center-col > .elementor-widget-wrap,
.ecity-expand-center-col > .elementor-column-wrap,
.ecity-expand-center-col > .elementor-column-wrap > .elementor-widget-wrap {
  overflow: visible !important;
}
.ecity-expand-right-col {
  position: relative;
  z-index: 4;
  pointer-events: none;
}
/* Students photo (749x701px visible + 12px right/bottom drop-shadow = 761x713px = 47.5625em x 44.5625em) */
.ecity-expand-students-img img {
  width: 100% !important;
  height: auto !important;
  border-radius: 0 !important;
  box-shadow: none !important;
  display: block !important;
}
/* Warm Sand Band (x=748, y=5285, w=915, h=466 -> 57.1875em x 29.125em, extending behind mascot!) */
@media (min-width: 1025px) {
  .ecity-expand-students-img img {
    width: 47.5625em !important;
    max-width: none !important;
    margin-left: -0.125em !important;
  }
  .ecity-expand-sand-box {
    width: 57.25em !important;
    min-width: 57.25em !important;
    max-width: none !important;
    flex: 0 0 57.25em !important;
    min-height: 29.125em !important;
    margin-left: -0.125em !important;
  }
  .ecity-expand-right-col,
  .ecity-expand-right-col > .elementor-widget-wrap,
  .ecity-expand-right-col > .elementor-column-wrap,
  .ecity-expand-right-col > .elementor-column-wrap > .elementor-widget-wrap {
    position: static !important;
  }
  .ecity-expand-mascot-img {
    position: absolute !important;
    right: 3.75em !important;
    top: 6.0em !important;
    width: 29.125em !important;
    max-width: none !important;
    margin: 0 !important;
    z-index: 4 !important;
    pointer-events: none;
  }
  .ecity-expand-mascot-img img {
    width: 29.125em !important;
    max-width: none !important;
    height: auto !important;
    display: block !important;
  }
}

/* === SECTION 10: FOOTER (1920x754px = 120em x 47.125em) === */
.ecity-footer-top-icons {
  max-width: 53.25em !important;
  margin-left: auto !important;
  margin-right: auto !important;
}
.ecity-footer-icon-phone img {
  width: 5.3125em !important;
  height: 5.3125em !important;
  object-fit: contain !important;
}
.ecity-footer-icon-std img {
  width: 4.375em !important;
  height: 4.375em !important;
  object-fit: contain !important;
}
.ecity-footer-links a {
  color: #FAFBFB !important;
  text-decoration: none !important;
  transition: color 0.2s ease;
}
.ecity-footer-links a:hover {
  color: #C66E52 !important;
}
/* Subscribe Input Pill: 388x56px = 24.25em x 3.5em, #6F6F6F */
.ecity-subscribe-form {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #6F6F6F;
  border-radius: 1.75em;
  height: 3.5em;
  padding: 0 1.4em;
  width: 100%;
  max-width: 24.25em;
  box-sizing: border-box;
}
.ecity-subscribe-input {
  background: transparent !important;
  border: none !important;
  outline: none !important;
  color: #FFFFFF !important;
  font-family: 'Inter', sans-serif;
  font-size: 1.25em;
  width: 100%;
}
.ecity-subscribe-input::placeholder {
  color: #FFFFFF;
  opacity: 0.95;
}
.ecity-subscribe-submit {
  background: transparent !important;
  border: none !important;
  color: #FFFFFF !important;
  font-size: 1.15em;
  cursor: pointer;
  padding: 0.25em 0 0.25em 0.75em;
}
/* 6 White Social Circles: 50x50px = 3.125em x 3.125em, gap 7px = 0.4375em */
.ecity-social-dots {
  display: flex;
  align-items: center;
  gap: 0.4375em;
  flex-wrap: nowrap;
}
.ecity-social-circle {
  width: 3.125em;
  height: 3.125em;
  border-radius: 50%;
  background: #FFFFFF;
  display: inline-block;
  flex-shrink: 0;
  transition: transform 0.2s ease, background-color 0.2s ease;
}
.ecity-social-circle:hover {
  transform: translateY(-0.2em);
  background: #C66E52;
}

/* === TABLET & MOBILE RESPONSIVE BREAKPOINTS (EM) === */
@media (max-width: 1024px) {
  .ecity-welcome-section {
    min-height: auto;
    overflow: hidden !important;
  }
  .ecity-welcome-left-col > .elementor-element-populated,
  .ecity-welcome-left-col > .elementor-widget-wrap,
  .ecity-welcome-left-col > .elementor-column-wrap > .elementor-widget-wrap {
    padding: 1.5em 1.25em !important;
  }
  .ecity-courses-section,
  .ecity-courses-mobile-section,
  .ecity-results-section,
  .ecity-events-section,
  .ecity-tour-section,
  .ecity-footer-section {
    padding-left: 1.5em !important;
    padding-right: 1.5em !important;
  }
  .ecity-tour-section > .elementor-container {
    flex-wrap: wrap !important;
  }
  .ecity-events-subtitle > .elementor-widget-container {
    margin-left: 1.0em !important;
    margin-right: 1.0em !important;
  }
  .ecity-expand-heading > .elementor-widget-container {
    margin-left: 0 !important;
    text-align: center !important;
  }
  .ecity-welcome-section::after,
  .ecity-welcome-mascot-widget {
    display: none !important;
  }
  .ecity-welcome-card {
    width: 100% !important;
    max-width: 100% !important;
    min-height: auto;
  }
  .ecity-campus-building-widget {
    position: relative !important;
    right: auto !important;
    bottom: auto !important;
    width: 100% !important;
  }
  .ecity-campus-building-widget img {
    width: 100% !important;
    max-width: 100% !important;
  }
  .ecity-course-circle-col {
    width: 6.5em !important;
    min-width: 6.5em !important;
    max-width: 6.5em !important;
    height: 6.5em !important;
    margin-right: 1.1em !important;
  }
  .ecity-subject-item {
    font-size: 1.15em;
  }
  .ecity-expand-sand-box {
    border-radius: 0.9375em !important;
    padding: 1.75em 1.35em !important;
    width: 100% !important;
    min-width: 0 !important;
    max-width: 100% !important;
    box-sizing: border-box !important;
  }
  .ecity-welcome-card {
    padding: 1.75em 1.35em !important;
    box-sizing: border-box !important;
  }
  .ecity-tour-white-frame > .elementor-element-populated,
  .ecity-tour-white-frame > .elementor-widget-wrap,
  .ecity-tour-white-frame > .elementor-column-wrap > .elementor-widget-wrap {
    padding: 1.25em !important;
  }
  .ecity-social-dots {
    flex-wrap: wrap;
  }
}

@media (max-width: 767px) {
  .ecity-welcome-left-col > .elementor-element-populated,
  .ecity-welcome-left-col > .elementor-widget-wrap,
  .ecity-welcome-left-col > .elementor-column-wrap > .elementor-widget-wrap {
    padding: 1.0em 0.5em !important;
  }
  .ecity-courses-section,
  .ecity-courses-mobile-section,
  .ecity-results-section,
  .ecity-events-section,
  .ecity-tour-section,
  .ecity-footer-section {
    padding-left: 0.9em !important;
    padding-right: 0.9em !important;
  }
  .ecity-course-row {
    padding-left: 0 !important;
  }
  .ecity-courses-rows-col > .elementor-element-populated,
  .ecity-courses-rows-col > .elementor-widget-wrap,
  .ecity-courses-photo-col > .elementor-element-populated,
  .ecity-courses-photo-col > .elementor-widget-wrap {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }
  .ecity-events-subtitle > .elementor-widget-container {
    margin-left: 0.25em !important;
    margin-right: 0.25em !important;
  }
  .ecity-logo-img img {
    width: 11.5em !important;
  }
  .ecity-play-btn-widget img {
    width: 6.5em !important;
    height: 6.5em !important;
  }
  .ecity-course-circle-col {
    width: 5.2em !important;
    min-width: 5.2em !important;
    max-width: 5.2em !important;
    height: 5.2em !important;
    margin-right: 0.75em !important;
  }
  .ecity-course-circle-icon img {
    width: 2.0em !important;
    height: 2.0em !important;
  }
  .ecity-course-pill-col {
    min-height: 5.5em !important;
  }
  .ecity-course-pill-col > .elementor-element-populated,
  .ecity-course-pill-col > .elementor-widget-wrap,
  .ecity-course-pill-col > .elementor-column-wrap > .elementor-widget-wrap {
    padding: 0.75em 0.85em !important;
  }
  .ecity-course-pill-grid {
    gap: 0.55em;
  }
  .ecity-course-pill-divider {
    height: 3.4em;
  }
  .ecity-subject-item {
    font-size: 0.85em;
    white-space: normal;
  }
  .ecity-arrow-btn img {
    width: 2.75em !important;
    height: 2.65em !important;
  }
  .ecity-events-carousel .swiper-slide img {
    height: 16em !important;
  }
  .ecity-subscribe-form {
    max-width: 100%;
  }
}

/* === BULLETPROOF BACKGROUND IMAGE FALLBACKS (FOR CROSS-SITE ELEMENTOR JSON IMPORT) === */
.ecity-welcome-section {
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_welcome_pattern_left.png") !important;
  background-position: top left !important;
  background-repeat: no-repeat !important;
}
.ecity-welcome-card {
  background-color: #C66E52 !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_welcome_card_bg_solid.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-admissions-section {
  background-color: #637982 !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_admissions_bg_solid.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-courses-section,
.ecity-courses-mobile-section {
  background-color: #ECD5BC !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_courses_sand_group.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-results-section {
  background-color: #FFFFFF !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_results_bg_solid.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-expand-section {
  background-color: #C66E52 !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_expand_bg_solid.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-expand-sand-box {
  background-color: #ECD5BC !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_expand_sand_box_solid.png") !important;
  background-position: center left !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-events-section {
  background-color: #FFFFFF !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_events_bg_solid.png") !important;
  background-position: top center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
.ecity-tour-section {
  background-color: #252525 !important;
  background-image: url("https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/ecity_virtual_tour_bg.png") !important;
  background-position: center center !important;
  background-repeat: no-repeat !important;
  background-size: cover !important;
}
</style>
<script>
(function() {
  const CDN = 'https://raw.githubusercontent.com/hemanthbv2/rvpu-assets/main/ecity/';
  const ASSET_MAP = {
    'ecity-asset-ecity_logo': 'ecity_logo.png',
    'ecity-asset-ecity_header_menu': 'ecity_header_menu.png',
    'ecity-asset-ecity_hero_play': 'ecity_hero_play.png',
    'ecity-asset-ecity_welcome_pattern_left': 'ecity_welcome_pattern_left.png',
    'ecity-asset-ecity_welcome_card_bg_solid': 'ecity_welcome_card_bg_solid.png',
    'ecity-asset-ecity_mascot_pointing': 'ecity_mascot_pointing.png',
    'ecity-asset-ecity_campus_building': 'ecity_campus_building.png',
    'ecity-asset-ecity_admissions_bg_solid': 'ecity_admissions_bg_solid.png',
    'ecity-asset-ecity_icon_phone_teal': 'ecity_icon_phone_teal.png',
    'ecity-asset-ecity_icon_email_teal': 'ecity_icon_email_teal.png',
    'ecity-asset-ecity_courses_sand_group': 'ecity_courses_sand_group.png',
    'ecity-asset-ecity_icon_pcmb': 'ecity_icon_pcmb.png',
    'ecity-asset-ecity_icon_pcmc': 'ecity_icon_pcmc.png',
    'ecity-asset-ecity_icon_sabe': 'ecity_icon_sabe.png',
    'ecity-asset-ecity_icon_bams': 'ecity_icon_bams.png',
    'ecity-asset-ecity_icon_bame': 'ecity_icon_bame.png',
    'ecity-asset-ecity_courses_lab_framed': 'ecity_courses_lab_framed.png',
    'ecity-asset-ecity_results_bg_solid': 'ecity_results_bg_solid.png',
    'ecity-asset-ecity_topper_card_full': 'ecity_topper_card_full.png',
    'ecity-asset-ecity_arrow_left': 'ecity_arrow_left.png',
    'ecity-asset-ecity_arrow_right': 'ecity_arrow_right.png',
    'ecity-asset-ecity_expand_bg_solid': 'ecity_expand_bg_solid.png',
    'ecity-asset-ecity_expand_circles': 'ecity_expand_circles.png',
    'ecity-asset-ecity_expand_sand_box_solid': 'ecity_expand_sand_box_solid.png',
    'ecity-asset-ecity_expand_students': 'ecity_expand_students.png',
    'ecity-asset-ecity_mascot_laptop': 'ecity_mascot_laptop.png',
    'ecity-asset-ecity_events_bg_solid': 'ecity_events_bg_solid.png',
    'ecity-asset-ecity_event_1': 'ecity_event_1.png',
    'ecity-asset-ecity_event_2': 'ecity_event_2.png',
    'ecity-asset-ecity_event_3': 'ecity_event_3.png',
    'ecity-asset-ecity_virtual_tour_bg': 'ecity_virtual_tour_bg.png',
    'ecity-asset-ecity_footer_phone': 'ecity_footer_phone.png',
    'ecity-asset-ecity_footer_email': 'ecity_footer_email.png',
    'ecity-asset-ecity_footer_map': 'ecity_footer_map.png',
    'ecity-asset-ecity_footer_privacy': 'ecity_footer_privacy.png'
  };

  function needsRestore(img) {
    if (!img) return false;
    const s = img.getAttribute('src') || '';
    return !s || s.indexOf('placeholder.png') !== -1 || (img.complete && img.naturalWidth === 0);
  }

  function setImgUrl(img, url) {
    if (!img) return;
    if (img.getAttribute('src') !== url) {
      img.setAttribute('src', url);
    }
    img.removeAttribute('srcset');
    img.removeAttribute('sizes');
  }

  function restorePlaceholderImages() {
    Object.keys(ASSET_MAP).forEach(function(cls) {
      const targetUrl = CDN + ASSET_MAP[cls];
      const imgs = document.querySelectorAll('.' + cls + ' img');
      imgs.forEach(function(img) {
        if (needsRestore(img)) {
          setImgUrl(img, targetUrl);
        }
        if (!img.dataset.ecityErrBound) {
          img.dataset.ecityErrBound = '1';
          img.addEventListener('error', function() {
            setImgUrl(img, targetUrl);
          });
        }
      });
    });

    // Also restore Results & Events carousel slide images if Elementor replaced them with placeholder.png
    const topperUrl = CDN + 'ecity_topper_card_full.png';
    document.querySelectorAll('.ecity-results-carousel .swiper-slide img').forEach(function(img) {
      if (needsRestore(img)) {
        setImgUrl(img, topperUrl);
      }
    });

    const eventUrls = [
      CDN + 'ecity_event_1.png',
      CDN + 'ecity_event_2.png',
      CDN + 'ecity_event_3.png'
    ];
    document.querySelectorAll('.ecity-events-carousel .swiper-slide img').forEach(function(img, idx) {
      if (needsRestore(img)) {
        setImgUrl(img, eventUrls[idx % eventUrls.length]);
      }
    });
  }
  function setupInfiniteCarousel(carouselSelector, prevSelector, nextSelector, desktopCount, gapDesktop, fallbackUrls) {
    const widgetEl = document.querySelector(carouselSelector);
    if (widgetEl && widgetEl.hasAttribute('data-settings')) {
      widgetEl.removeAttribute('data-settings');
    }
    let container = document.querySelector(carouselSelector + ' .swiper, ' + carouselSelector + ' .swiper-container');
    if (!container && widgetEl && fallbackUrls && fallbackUrls.length) {
      const wCont = widgetEl.querySelector('.elementor-widget-container') || widgetEl;
      const slidesHtml = fallbackUrls.map(function(u) {
        return '<div class="swiper-slide"><figure class="swiper-slide-inner"><img class="swiper-slide-image" src="' + u + '" loading="eager" alt="" /></figure></div>';
      }).join('');
      wCont.innerHTML = '<div class="elementor-image-carousel-wrapper swiper" dir="ltr"><div class="elementor-image-carousel swiper-wrapper">' + slidesHtml + '</div></div>';
      container = wCont.querySelector('.swiper');
    }
    if (!container) return;
    if (container.swiper && typeof container.swiper.destroy === 'function') {
      try { container.swiper.destroy(false, false); } catch (e) {}
    }
    const wrapper = container.querySelector('.swiper-wrapper');
    if (!wrapper) return;
    if (wrapper.dataset.ecityInit === '1') {
      if (typeof wrapper._ecityRefresh === 'function') wrapper._ecityRefresh();
      return;
    }

    const rawSlides = Array.from(wrapper.querySelectorAll('.swiper-slide:not(.swiper-slide-duplicate)'));
    if (rawSlides.length < 2) return;
    wrapper.dataset.ecityInit = '1';

    const origHTML = rawSlides.map(function(s) {
      return s.outerHTML.replace(/loading=["']lazy["']/gi, 'loading="eager"');
    });
    const N = origHTML.length;
    wrapper.innerHTML = origHTML.concat(origHTML).concat(origHTML).join('');
    const allSlides = Array.from(wrapper.children);

    container.style.overflow = 'hidden';
    container.style.width = '100%';
    wrapper.style.display = 'flex';
    wrapper.style.flexWrap = 'nowrap';
    wrapper.style.boxSizing = 'border-box';
    wrapper.style.willChange = 'transform';

    let currentIndex = N;
    let isAnimating = false;

    function getVisibleCount() {
      if (window.innerWidth <= 767) return 1;
      if (window.innerWidth <= 1024) return 2;
      return desktopCount;
    }

    function getGapPx() {
      if (window.innerWidth <= 767) return 16;
      return Math.round((window.innerWidth / 1920) * gapDesktop);
    }

    function getSlideStep() {
      const vis = getVisibleCount();
      const gapPx = getGapPx();
      const cWidth = container.clientWidth || 1200;
      const slideW = (cWidth - gapPx * (vis - 1)) / vis;
      return { vis: vis, gapPx: gapPx, slideW: slideW, step: slideW + gapPx };
    }

    function applyClasses(animate) {
      const m = getSlideStep();
      allSlides.forEach(function(s) {
        s.style.width = m.slideW + 'px';
        s.style.minWidth = m.slideW + 'px';
        s.style.maxWidth = m.slideW + 'px';
        s.style.marginRight = m.gapPx + 'px';
        s.style.flexShrink = '0';
        s.style.boxSizing = 'border-box';
      });
      wrapper.style.transition = animate ? 'transform 520ms cubic-bezier(0.22, 1, 0.36, 1)' : 'none';
      const offset = -(currentIndex * m.step);
      wrapper.style.transform = 'translate3d(' + offset + 'px, 0, 0)';
    }
    wrapper._ecityRefresh = function() { applyClasses(false); };

    function nextSlide() {
      if (isAnimating) return;
      isAnimating = true;
      currentIndex += 1;
      applyClasses(true);
    }

    function prevSlide() {
      if (isAnimating) return;
      isAnimating = true;
      currentIndex -= 1;
      applyClasses(true);
    }

    wrapper.addEventListener('transitionend', function(e) {
      if (e.target !== wrapper) return;
      isAnimating = false;
      if (currentIndex >= 2 * N) {
        currentIndex -= N;
        applyClasses(false);
      } else if (currentIndex < N) {
        currentIndex += N;
        applyClasses(false);
      }
    });

    applyClasses(false);
    window.addEventListener('resize', function() { applyClasses(false); });

    const prevBtn = document.querySelector(prevSelector);
    const nextBtn = document.querySelector(nextSelector);
    if (prevBtn) {
      prevBtn.addEventListener('click', function(e) {
        e.preventDefault();
        prevSlide();
        resetTimer();
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', function(e) {
        e.preventDefault();
        nextSlide();
        resetTimer();
      });
    }

    let timer = setInterval(nextSlide, 2800);
    function resetTimer() {
      clearInterval(timer);
      timer = setInterval(nextSlide, 2800);
    }
    container.addEventListener('mouseenter', function() { clearInterval(timer); });
    container.addEventListener('mouseleave', function() { resetTimer(); });
  }

  function initAll() {
    restorePlaceholderImages();
    const resultsFallback = [
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png',
      CDN + 'ecity_topper_card_full.png'
    ];
    const eventsFallback = [
      CDN + 'ecity_event_1.png',
      CDN + 'ecity_event_2.png',
      CDN + 'ecity_event_3.png',
      CDN + 'ecity_event_1.png',
      CDN + 'ecity_event_2.png',
      CDN + 'ecity_event_3.png'
    ];
    setupInfiniteCarousel('.ecity-results-carousel', '.ecity-results-prev', '.ecity-results-next', 4, 31, resultsFallback);
    setupInfiniteCarousel('.ecity-events-carousel', '.ecity-events-prev', '.ecity-events-next', 3, 27, eventsFallback);
    restorePlaceholderImages();
  }

  initAll();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      initAll();
      setTimeout(initAll, 250);
      setTimeout(initAll, 700);
      setTimeout(initAll, 1500);
    });
  } else {
    setTimeout(initAll, 250);
    setTimeout(initAll, 700);
    setTimeout(initAll, 1500);
  }
  window.addEventListener('load', function() {
    initAll();
    setTimeout(initAll, 450);
    setTimeout(initAll, 1200);
  });
  if (typeof MutationObserver !== 'undefined' && document.body) {
    let debounceTimer = null;
    const obs = new MutationObserver(function() {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(restorePlaceholderImages, 150);
    });
    obs.observe(document.body, { childList: true, subtree: true });
  }
})();
</script>`
                    },
                    elements: []
                  }
                ],
                true
              )
            ],
            true
          )
        ]
      )
    ]
  )
];

// Save updated standalone Elementor template JSON
const templateExport = {
  version: '0.4',
  title: 'RVPU E-City - Homepage 3 (Native Elementor, EM Responsive)',
  type: 'page',
  content: elementorData
};

const artifactJsonPath = 'C:/Users/HP/.gemini/antigravity/brain/c5c230c2-90b4-4fe7-b358-32b81fcbace0/rvpu-ecity-homepage3-elementor-template.json';
fs.writeFileSync(artifactJsonPath, JSON.stringify(templateExport, null, 2));
console.log('Saved Elementor template JSON to:', artifactJsonPath);

const workspaceJsonPath = 'd:/hemanth bv/test/rvpu_ecity_elementor_template.json';
fs.writeFileSync(workspaceJsonPath, JSON.stringify(templateExport, null, 2));
console.log('Saved Workspace Elementor template JSON to:', workspaceJsonPath);

import { callTool } from '../rvps/mcp.mjs';

const pageIds = process.argv[2] ? [Number(process.argv[2])] : [125, 167];
for (const targetId of pageIds) {
  const res = await callTool('wp_save_elementor_page', {
    pageId: targetId,
    title: 'RVPU E-City — Homepage 3',
    status: 'publish',
    template: 'elementor_canvas',
    elementorData
  });
  console.log(`Save Page ${targetId} Result:`, JSON.stringify(res, null, 2));
}

